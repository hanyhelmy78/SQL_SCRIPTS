﻿namespace XESmartTarget.Core
{
    internal class Logger
    {
    }
}