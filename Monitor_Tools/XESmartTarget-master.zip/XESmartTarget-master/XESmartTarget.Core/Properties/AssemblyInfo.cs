﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("c9c968d1-4aa9-4674-bbe4-c08b9c169147")]

