# Third-Party Notices

This software includes the following third-party packages. All are distributed
under open-source licenses compatible with the MIT license.

## MIT License

The following packages are licensed under the [MIT License](https://opensource.org/licenses/MIT):

| Package | Version | Copyright |
|---------|---------|-----------|
| [Avalonia](https://github.com/AvaloniaUI/Avalonia) | 11.3.9 | © AvaloniaUI |
| [Avalonia.Controls.DataGrid](https://github.com/AvaloniaUI/Avalonia) | 11.3.9 | © AvaloniaUI |
| [Avalonia.Desktop](https://github.com/AvaloniaUI/Avalonia) | 11.3.9 | © AvaloniaUI |
| [Avalonia.Fonts.Inter](https://github.com/AvaloniaUI/Avalonia) | 11.3.9 | © AvaloniaUI |
| [Avalonia.ReactiveUI](https://github.com/AvaloniaUI/Avalonia) | 11.3.9 | © AvaloniaUI |
| [Avalonia.Themes.Fluent](https://github.com/AvaloniaUI/Avalonia) | 11.3.9 | © AvaloniaUI |
| [Avalonia.Diagnostics](https://github.com/AvaloniaUI/Avalonia) | 11.3.9 | © AvaloniaUI |
| [ReactiveUI](https://github.com/reactiveui/ReactiveUI) | 20.1.1 | © ReactiveUI contributors |
| [System.Reactive](https://github.com/dotnet/reactive) | 6.1.0 | © .NET Foundation |
| [DynamicData](https://github.com/reactivemarbles/DynamicData) | 8.4.1 | © ReactiveUI contributors |
| [Splat](https://github.com/reactiveui/splat) | 15.1.1 | © ReactiveUI contributors |
| [LiveChartsCore.SkiaSharpView.Avalonia](https://github.com/beto-rodriguez/LiveCharts2) | 2.0.0 | © Alberto Rodriguez |
| [SkiaSharp](https://github.com/mono/SkiaSharp) | 2.88.9 | © Microsoft Corporation |
| [HarfBuzzSharp](https://github.com/nicknijenhuis/HarfBuzzSharp) | 8.3.1.1 | © Microsoft Corporation |
| [ClosedXML](https://github.com/ClosedXML/ClosedXML) | 0.105.0 | © ClosedXML contributors |
| [DocumentFormat.OpenXml](https://github.com/dotnet/Open-XML-SDK) | 3.1.1 | © Microsoft Corporation |
| [ExcelNumberFormat](https://github.com/andersnm/ExcelNumberFormat) | 1.1.0 | © andersnm |
| [DuckDB.NET.Data.Full](https://github.com/Giorgi/DuckDB.NET) | 1.5.0 | © Giorgi Dalakishvili |
| [Microsoft.Data.SqlClient](https://github.com/dotnet/SqlClient) | 7.0.0 | © Microsoft Corporation |
| [Microsoft.Extensions.DependencyInjection](https://github.com/dotnet/runtime) | 10.0.5 | © Microsoft Corporation |
| [Microsoft.Extensions.DependencyInjection.Abstractions](https://github.com/dotnet/runtime) | 10.0.5 | © Microsoft Corporation |
| [Microsoft.Extensions.Logging](https://github.com/dotnet/runtime) | 10.0.5 | © Microsoft Corporation |
| [Microsoft.Extensions.Logging.Abstractions](https://github.com/dotnet/runtime) | 10.0.5 | © Microsoft Corporation |
| [Microsoft.Extensions.Hosting.WindowsServices](https://github.com/dotnet/runtime) | 9.0.6 | © Microsoft Corporation |
| [Microsoft.AspNetCore.Authentication.JwtBearer](https://github.com/dotnet/aspnetcore) | 9.0.6 | © Microsoft Corporation |
| [Microsoft.AspNetCore.SignalR.Client](https://github.com/dotnet/aspnetcore) | 9.0.6 | © Microsoft Corporation |
| [BCrypt.Net-Next](https://github.com/BcryptNet/bcrypt.net) | 4.0.3 | © Chris McKee, Ryan D. Emerl, Damien Miller |
| [System.Security.Cryptography.ProtectedData](https://github.com/dotnet/runtime) | 10.0.5 | © Microsoft Corporation |
| [System.IO.FileSystem.AccessControl](https://github.com/dotnet/runtime) | 5.0.0 | © Microsoft Corporation |
| [System.ServiceProcess.ServiceController](https://github.com/dotnet/runtime) | 10.0.5 | © Microsoft Corporation |
| [Tmds.DBus.Protocol](https://github.com/tmds/Tmds.DBus) | 0.21.3 | © Tom Deseyn |

## BSD 3-Clause License

The following packages are licensed under the
[BSD 3-Clause License](https://opensource.org/licenses/BSD-3-Clause):

| Package | Version | Copyright |
|---------|---------|-----------|
| [NSubstitute](https://github.com/nsubstitute/NSubstitute) | 5.3.0 | © NSubstitute contributors |

## Apache License 2.0

The following packages are licensed under the
[Apache License 2.0](https://opensource.org/licenses/Apache-2.0):

| Package | Version | Copyright |
|---------|---------|-----------|
| [SixLabors.Fonts](https://github.com/SixLabors/Fonts) | 1.0.0 | © Six Labors |
| [MinVer](https://github.com/adamralph/minver) | 6.0.0 | © MinVer contributors |
