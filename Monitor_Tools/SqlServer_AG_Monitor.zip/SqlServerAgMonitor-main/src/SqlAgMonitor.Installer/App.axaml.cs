using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using SqlAgMonitor.Installer.ViewModels;
using SqlAgMonitor.Installer.Views;

namespace SqlAgMonitor.Installer;

public partial class App : Application
{
    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            desktop.MainWindow = new InstallerWindow
            {
                DataContext = new InstallerViewModel()
            };
        }

        base.OnFrameworkInitializationCompleted();
    }
}
