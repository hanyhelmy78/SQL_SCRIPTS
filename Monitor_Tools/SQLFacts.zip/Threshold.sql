/* ------------------------------ *\

   � Copyright 2021 by Wingenious

   see README for license details

\* ------------------------------ */


SET NOCOUNT ON

DECLARE @Seconds_AVG decimal(19,05) = NULL -- minimum number for Seconds_AVG, NULL means use value at Percentile below
DECLARE @Seconds_MIN decimal(19,05) = NULL -- minimum number for Seconds_MIN, NULL means use value at Percentile below
DECLARE @Seconds_MAX decimal(19,05) = NULL -- minimum number for Seconds_MAX, NULL means use value at Percentile below

DECLARE @Percentile smallint = 90

DECLARE @CPU_time bit = 1
--      @CPU_time     = 0 means Seconds are run time
--      @CPU_time     = 1 means Seconds are CPU time

DECLARE @BaseVersion varchar(1000) = CONVERT(varchar(1000), SERVERPROPERTY('ProductVersion'))

DECLARE @Information varchar(4000) =
CASE WHEN    @@VERSION LIKE '%Azure%' THEN 'SQL Server PaaS '
     WHEN @BaseVersion LIKE    '8.%'  THEN 'SQL Server 2000 '
     WHEN @BaseVersion LIKE    '9.%'  THEN 'SQL Server 2005 '
     WHEN @BaseVersion LIKE   '10.0%' THEN 'SQL Server 2008 '
     WHEN @BaseVersion LIKE   '10.5%' THEN 'SQL Server 2008 R2 '
     WHEN @BaseVersion LIKE   '11.%'  THEN 'SQL Server 2012 '
     WHEN @BaseVersion LIKE   '12.%'  THEN 'SQL Server 2014 '
     WHEN @BaseVersion LIKE   '13.%'  THEN 'SQL Server 2016 '
     WHEN @BaseVersion LIKE   '14.%'  THEN 'SQL Server 2017 '
     WHEN @BaseVersion LIKE   '15.%'  THEN 'SQL Server 2019 '
     WHEN @BaseVersion LIKE   '16.%'  THEN 'SQL Server 2022 ' ELSE 'SQL Server ' END
+ CONVERT(varchar(1000), SERVERPROPERTY('Edition')) + ' has been running since '
+ CONVERT(varchar(1000), (SELECT I.sqlserver_start_time FROM sys.dm_os_sys_info AS I), 120)

PRINT @Information

DECLARE @MAXDOP    bigint = (SELECT CONVERT(bigint, value_in_use) FROM sys.configurations WHERE name LIKE 'ma% parallelism')

DECLARE @Threshold bigint = (SELECT CONVERT(bigint, value_in_use) FROM sys.configurations WHERE name LIKE 'co% parallelism')

DECLARE @T TABLE (Percentile smallint)

INSERT @T VALUES (10), (20), (30), (40), (50), (60), (70), (80), (90), (100)

   SELECT S.sql_handle
        , S.execution_count
        , CONVERT(decimal(19,05), CASE WHEN @CPU_time = 0 THEN S.total_elapsed_time ELSE S.total_worker_time END / 1000.0 / 1000.0 / S.execution_count) AS Seconds_AVG
        , CONVERT(decimal(19,05), CASE WHEN @CPU_time = 0 THEN   S.min_elapsed_time ELSE   S.min_worker_time END / 1000.0 / 1000.0                    ) AS Seconds_MIN
        , CONVERT(decimal(19,05), CASE WHEN @CPU_time = 0 THEN   S.max_elapsed_time ELSE   S.max_worker_time END / 1000.0 / 1000.0                    ) AS Seconds_MAX
     INTO #Action
     FROM sys.dm_exec_query_stats     AS S
     JOIN sys.dm_exec_procedure_stats AS Z
       ON S.sql_handle
        = Z.sql_handle
    WHERE Z.database_id > 4

   SELECT      T.Percentile
        , CASE T.Percentile WHEN  10 THEN W.P10
                            WHEN  20 THEN W.P20
                            WHEN  30 THEN W.P30
                            WHEN  40 THEN W.P40
                            WHEN  50 THEN W.P50
                            WHEN  60 THEN W.P60
                            WHEN  70 THEN W.P70
                            WHEN  80 THEN W.P80
                            WHEN  90 THEN W.P90
                            WHEN 100 THEN W.P00 END AS Seconds_AVG
        , CASE T.Percentile WHEN  10 THEN X.P10
                            WHEN  20 THEN X.P20
                            WHEN  30 THEN X.P30
                            WHEN  40 THEN X.P40
                            WHEN  50 THEN X.P50
                            WHEN  60 THEN X.P60
                            WHEN  70 THEN X.P70
                            WHEN  80 THEN X.P80
                            WHEN  90 THEN X.P90
                            WHEN 100 THEN X.P00 END AS Seconds_MIN
        , CASE T.Percentile WHEN  10 THEN Y.P10
                            WHEN  20 THEN Y.P20
                            WHEN  30 THEN Y.P30
                            WHEN  40 THEN Y.P40
                            WHEN  50 THEN Y.P50
                            WHEN  60 THEN Y.P60
                            WHEN  70 THEN Y.P70
                            WHEN  80 THEN Y.P80
                            WHEN  90 THEN Y.P90
                            WHEN 100 THEN Y.P00 END AS Seconds_MAX
     INTO #Percentile
     FROM @T AS T
, (SELECT DISTINCT 'Seconds_AVG' AS Metric
        , PERCENTILE_DISC(0.10) WITHIN GROUP (ORDER BY Seconds_AVG) OVER () AS P10
        , PERCENTILE_DISC(0.20) WITHIN GROUP (ORDER BY Seconds_AVG) OVER () AS P20
        , PERCENTILE_DISC(0.30) WITHIN GROUP (ORDER BY Seconds_AVG) OVER () AS P30
        , PERCENTILE_DISC(0.40) WITHIN GROUP (ORDER BY Seconds_AVG) OVER () AS P40
        , PERCENTILE_DISC(0.50) WITHIN GROUP (ORDER BY Seconds_AVG) OVER () AS P50
        , PERCENTILE_DISC(0.60) WITHIN GROUP (ORDER BY Seconds_AVG) OVER () AS P60
        , PERCENTILE_DISC(0.70) WITHIN GROUP (ORDER BY Seconds_AVG) OVER () AS P70
        , PERCENTILE_DISC(0.80) WITHIN GROUP (ORDER BY Seconds_AVG) OVER () AS P80
        , PERCENTILE_DISC(0.90) WITHIN GROUP (ORDER BY Seconds_AVG) OVER () AS P90
        , (SELECT MAX(Seconds_AVG) FROM #Action)                            AS P00
      FROM #Action) AS W
, (SELECT DISTINCT 'Seconds_MIN' AS Metric
        , PERCENTILE_DISC(0.10) WITHIN GROUP (ORDER BY Seconds_MIN) OVER () AS P10
        , PERCENTILE_DISC(0.20) WITHIN GROUP (ORDER BY Seconds_MIN) OVER () AS P20
        , PERCENTILE_DISC(0.30) WITHIN GROUP (ORDER BY Seconds_MIN) OVER () AS P30
        , PERCENTILE_DISC(0.40) WITHIN GROUP (ORDER BY Seconds_MIN) OVER () AS P40
        , PERCENTILE_DISC(0.50) WITHIN GROUP (ORDER BY Seconds_MIN) OVER () AS P50
        , PERCENTILE_DISC(0.60) WITHIN GROUP (ORDER BY Seconds_MIN) OVER () AS P60
        , PERCENTILE_DISC(0.70) WITHIN GROUP (ORDER BY Seconds_MIN) OVER () AS P70
        , PERCENTILE_DISC(0.80) WITHIN GROUP (ORDER BY Seconds_MIN) OVER () AS P80
        , PERCENTILE_DISC(0.90) WITHIN GROUP (ORDER BY Seconds_MIN) OVER () AS P90
        , (SELECT MAX(Seconds_MIN) FROM #Action)                            AS P00
      FROM #Action) AS X
, (SELECT DISTINCT 'Seconds_MAX' AS Metric
        , PERCENTILE_DISC(0.10) WITHIN GROUP (ORDER BY Seconds_MAX) OVER () AS P10
        , PERCENTILE_DISC(0.20) WITHIN GROUP (ORDER BY Seconds_MAX) OVER () AS P20
        , PERCENTILE_DISC(0.30) WITHIN GROUP (ORDER BY Seconds_MAX) OVER () AS P30
        , PERCENTILE_DISC(0.40) WITHIN GROUP (ORDER BY Seconds_MAX) OVER () AS P40
        , PERCENTILE_DISC(0.50) WITHIN GROUP (ORDER BY Seconds_MAX) OVER () AS P50
        , PERCENTILE_DISC(0.60) WITHIN GROUP (ORDER BY Seconds_MAX) OVER () AS P60
        , PERCENTILE_DISC(0.70) WITHIN GROUP (ORDER BY Seconds_MAX) OVER () AS P70
        , PERCENTILE_DISC(0.80) WITHIN GROUP (ORDER BY Seconds_MAX) OVER () AS P80
        , PERCENTILE_DISC(0.90) WITHIN GROUP (ORDER BY Seconds_MAX) OVER () AS P90
        , (SELECT MAX(Seconds_MAX) FROM #Action)                            AS P00
      FROM #Action) AS Y
 ORDER BY CONVERT(smallint, T.Percentile)

IF @Seconds_AVG IS NULL SELECT @Seconds_AVG = P.Seconds_AVG FROM #Percentile AS P WHERE P.Percentile BETWEEN @Percentile - 9 AND @Percentile
IF @Seconds_MIN IS NULL SELECT @Seconds_MIN = P.Seconds_MIN FROM #Percentile AS P WHERE P.Percentile BETWEEN @Percentile - 9 AND @Percentile
IF @Seconds_MAX IS NULL SELECT @Seconds_MAX = P.Seconds_MAX FROM #Percentile AS P WHERE P.Percentile BETWEEN @Percentile - 9 AND @Percentile

   SELECT A.sql_handle
     INTO #Action_Procedure
     FROM #Action AS A
    WHERE CASE WHEN A.Seconds_AVG !< @Seconds_AVG THEN 1
               WHEN A.Seconds_MIN !< @Seconds_MIN THEN 1
               WHEN A.Seconds_MAX !< @Seconds_MAX THEN 1 ELSE 0 END != 0
 GROUP BY A.sql_handle

   SELECT E.*
        , ROW_NUMBER() OVER (PARTITION BY E.sql_handle ORDER BY E.I) AS StatementID
        , CONVERT(int, 0) AS T
        , CONVERT(int, 0) AS W
        , CONVERT(int, 0) AS Z
     INTO #Action_Statement
     FROM
  (SELECT S.execution_count                                   AS Executions
        , CONVERT(varchar(0040) ,       S.creation_time, 120) AS Creation
        , CONVERT(varchar(0040) , S.last_execution_time, 120) AS Last_Run
        , CONVERT(decimal(19,05), CASE WHEN @CPU_time = 0 THEN S.total_elapsed_time ELSE S.total_worker_time END / 1000.0 / 1000.0 / S.execution_count) AS Seconds_AVG
        , CONVERT(decimal(19,05), CASE WHEN @CPU_time = 0 THEN S.total_elapsed_time ELSE S.total_worker_time END / 1000.0 / 1000.0                    ) AS Seconds_SUM
        , CONVERT(decimal(19,05), CASE WHEN @CPU_time = 0 THEN  S.last_elapsed_time ELSE  S.last_worker_time END / 1000.0 / 1000.0                    ) AS Seconds_LST
        , CONVERT(decimal(19,05), CASE WHEN @CPU_time = 0 THEN   S.min_elapsed_time ELSE   S.min_worker_time END / 1000.0 / 1000.0                    ) AS Seconds_MIN
        , CONVERT(decimal(19,05), CASE WHEN @CPU_time = 0 THEN   S.max_elapsed_time ELSE   S.max_worker_time END / 1000.0 / 1000.0                    ) AS Seconds_MAX
        , S.total_logical_writes / S.execution_count AS Writes_AVG
        , S.total_logical_writes                     AS Writes_SUM
        ,  S.last_logical_writes                     AS Writes_LST
        ,   S.min_logical_writes                     AS Writes_MIN
        ,   S.max_logical_writes                     AS Writes_MAX
        ,  S.total_logical_reads / S.execution_count AS LReads_AVG
        ,  S.total_logical_reads                     AS LReads_SUM
        ,   S.last_logical_reads                     AS LReads_LST
        ,    S.min_logical_reads                     AS LReads_MIN
        ,    S.max_logical_reads                     AS LReads_MAX
        , S.total_physical_reads / S.execution_count AS PReads_AVG
        , S.total_physical_reads                     AS PReads_SUM
        ,  S.last_physical_reads                     AS PReads_LST
        ,   S.min_physical_reads                     AS PReads_MIN
        ,   S.max_physical_reads                     AS PReads_MAX
        ,           S.total_rows / S.execution_count AS Rows_AVG
        ,           S.total_rows                     AS Rows_SUM
        ,            S.last_rows                     AS Rows_LST
        ,             S.min_rows                     AS Rows_MIN
        ,             S.max_rows                     AS Rows_MAX
        ,            DB_NAME(            V.dbid) AS DBName
        , OBJECT_SCHEMA_NAME(V.objectid, V.dbid) AS SchemaName
        ,        OBJECT_NAME(V.objectid, V.dbid) AS ObjectName
        ,                               SPACE(2) AS ObjectType
        , CASE WHEN S.statement_start_offset < 0 THEN     0                                                                            ELSE (S.statement_start_offset / 2)     END + 1 AS I
        , CASE WHEN S.statement_end_offset   < 0 THEN LEN(T.text) WHEN S.statement_end_offset > (LEN(T.text) * 2) - 4 THEN LEN(T.text) ELSE (S.statement_end_offset   / 2) + 1 END + 1 AS O
        , T.text
        , S.sql_handle
        , REPLACE(REPLACE(CONVERT(nvarchar(max), V.query_plan), '[', '{'), ']', '}') AS query_plan
     FROM #Action_Procedure AS A
     JOIN sys.dm_exec_query_stats AS S
       ON A.sql_handle
        = S.sql_handle
    OUTER APPLY sys.dm_exec_sql_text(S.sql_handle) AS T OUTER APPLY sys.dm_exec_query_plan(S.plan_handle) AS V) AS E
 ORDER BY E.SchemaName
        , E.ObjectName
        , E.I

   UPDATE #Action_Statement SET T = CHARINDEX(LEFT(REPLACE(SUBSTRING(E.text, E.I, E.O - E.I), CHAR(13) + CHAR(10), '&#x0D;&#x0A;'), 4000), E.query_plan, 1)
     FROM #Action_Statement AS E

   UPDATE #Action_Statement SET W = CHARINDEX('StatementSubTreeCost="', E.query_plan, E.T + E.O - E.I)
     FROM #Action_Statement AS E

   UPDATE #Action_Statement SET Z = CHARINDEX('"', E.query_plan, E.W + 22)
     FROM #Action_Statement AS E

/*

   SELECT @Seconds_AVG AS Seconds_AVG
        , @Seconds_MIN AS Seconds_MIN
        , @Seconds_MAX AS Seconds_MAX
        , @Threshold   AS Threshold
        , @MAXDOP      AS MAXDOP

*/

   SELECT P.Percentile
        , P.Seconds_AVG
        , P.Seconds_MIN
        , P.Seconds_MAX
     FROM  #Percentile AS P
 ORDER BY P.Percentile

   SELECT U.*
        , CASE WHEN U.Seconds_AVG  !< @Seconds_AVG THEN 'Over_AVG'  ELSE NULL END AS Over_AVG
        , CASE WHEN U.Seconds_MIN  !< @Seconds_MIN THEN 'Over_MIN'  ELSE NULL END AS Over_MIN
        , CASE WHEN U.Seconds_MAX  !< @Seconds_MAX THEN 'Over_MAX'  ELSE NULL END AS Over_MAX
        , CASE WHEN U.CostEstimate !< @Threshold   THEN 'Threshold' ELSE NULL END AS Threshold
     FROM
  (SELECT E.Executions
        , E.Creation
        , E.Last_Run
        , E.Seconds_AVG -- average
        , E.Seconds_MIN -- minimum
        , E.Seconds_MAX -- maximum
        , E.Writes_AVG
        , E.Writes_MIN
        , E.Writes_MAX
        , E.LReads_AVG
        , E.LReads_MIN
        , E.LReads_MAX
--      , E.PReads_AVG
--      , E.PReads_MIN
--      , E.PReads_MAX
--      , E.Rows_AVG
--      , E.Rows_MIN
--      , E.Rows_MAX
        , E.SchemaName
        , E.ObjectName
--      , E.ObjectType
--      , E.query_plan
        , SUBSTRING(E.text, E.I, E.O - E.I) AS SQL_code
--      ,           E.text                  AS SQL_code_all
        , E.StatementID AS Query
        , CONVERT(decimal(19,05), CONVERT(float(53), CASE WHEN E.T > 0 AND E.W > 0 AND E.W < E.Z THEN SUBSTRING(E.query_plan, E.W + 22, E.Z - E.W - 22) ELSE NULL END)) AS CostEstimate
     FROM #Action_Statement AS E) AS U
    WHERE CASE WHEN U.Seconds_AVG !< @Seconds_AVG THEN 1
               WHEN U.Seconds_MIN !< @Seconds_MIN THEN 1
               WHEN U.Seconds_MAX !< @Seconds_MAX THEN 1 ELSE 0 END != 0
 ORDER BY U.SchemaName
        , U.ObjectName
        , U.Query

DROP TABLE #Action

DROP TABLE #Percentile

DROP TABLE #Action_Procedure

DROP TABLE #Action_Statement

SET NOCOUNT OFF

