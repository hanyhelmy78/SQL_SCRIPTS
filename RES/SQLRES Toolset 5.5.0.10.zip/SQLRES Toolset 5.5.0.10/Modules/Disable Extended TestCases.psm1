#This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.
#THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
#INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
#We grant you a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute
#the object code form of the Sample Code, provided that you agree:
#(i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded;
#(ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and
#(iii) to indemnify, hold harmless, and defend Us and our suppliers from and against any claims or lawsuits, including attorneys' fees, that arise or result from the use or distribution of the Sample Code. 
# ----------------------------------------------------------------------------- 
# Script: Disable Extended TesCases.psm1 
# Author: oliverha 
# Date: 09/10/2022 17:06:32
# Version:  5.0
# Keywords: 
# comments: 
# 5.0 Initial version for SQL 2019 release
# ----------------------------------------------------------------------------- 
function Disable-ExtendedTestCases()
{ 
 <# 
   .Synopsis 
    Disables Extended TestCases
   .Description
    Disables Extended TestCases
	TestCaseLevel:@Admin	
   .Notes  
   .Example 
    Disable-ExtendedTestCases
   .Link 
    http://aka.ms/sqlres
 #> 
[CmdletBinding()]
param()
Set-StrictMode -Version 2.0

$Global:ExtendedTestCases = $false
Write-Host "Experimental Testcases disabled."
return

}
